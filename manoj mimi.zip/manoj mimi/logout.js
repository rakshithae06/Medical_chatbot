// document.getElementById('closePopup').addEventListener('click', function() {
//     document.getElementById('logoutPopup').style.display = 'none';
//     window.location.href = 'signin.html'; // Redirect to sign-in page
// });

// // Automatically show the popup when the page loads
// window.onload = function() {
//     document.getElementById('logoutPopup').style.display = 'block';
// };
document.getElementById('closePopup').addEventListener('click', function() {
    document.getElementById('logoutPopup').style.display = 'none';
    setTimeout(function() {
        window.location.href = 'signin.html'; // Redirect to sign-in page
    }, 500); // 500 milliseconds delay before redirect
});

// Automatically show the popup when the page loads
window.onload = function() {
    document.getElementById('logoutPopup').style.display = 'block';
};
