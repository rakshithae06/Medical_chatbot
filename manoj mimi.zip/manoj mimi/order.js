document.querySelector('.back-to-home').addEventListener('click', function() {
    window.location.href = 'homepage.html'; // Redirect to home page
});


    document.addEventListener("DOMContentLoaded", () => {
        loadOrders();
    });

    function loadOrders() {
        const orders = JSON.parse(localStorage.getItem("orders")) || [];
        const ordersContainer = document.querySelector(".orders-content");

        if (orders.length === 0) {
            ordersContainer.innerHTML = "<p>No orders yet!</p>";
            return;
        }

        ordersContainer.innerHTML = orders
            .map(
                (order) => `
                <div class="order">
                    <h3>Order ID: ${order.id}</h3>
                    <p><strong>Order Date:</strong> ${order.date}</p>
                    <p><strong>Delivery Date & Time:</strong> ${order.deliveryDate}, ${order.deliveryTime}</p>
                    <h4>Products:</h4>
                    <ul>
                        ${order.items
                            .map(
                                (item) => `
                            <li>
                                <div class="product-item">
                                    <img src="${item.imgSrc}" alt="${item.name}">
                                    <div class="product-details">
                                        <h5>${item.name}</h5>
                                        <p>Quantity: ${item.quantity}</p>
                                        <p>Price: ₹${calculateTotal(item)}</p>
                                    </div>
                                </div>
                            </li>
                        `
                            )
                            .join("")}
                    </ul>
                    <p class="total-amount"><strong>Total Amount: ₹${order.totalAmount}</strong></p>
                </div>
            `
            )
            .join("");
    }

    function calculateTotal(item) {
        const price = parseInt(item.price.replace("Rs", "").replace("/", "").trim());
        return price * item.quantity;
    }

