// Predefined static users with their emails and passwords
const users = [
    { email: "manoz@gmail.com", password: "123" },
    { email: "narendra@gmail.com", password: "1234" },
    { email: "prashanth@gmail.com", password: "12345" },
    { email: "sanjay@gmail.com", password: "01234" }
];

// Get the form elements
const signInForm = document.getElementById("signInForm");
const signUpForm = document.getElementById("signUpForm");

// Event listener for the sign-in form submission
signInForm.addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission

    const email = signInForm.querySelector('input[type="email"]').value;
    const password = signInForm.querySelector('input[type="password"]').value;

    // Check if the entered email and password match any of the predefined users
    const user = users.find(user => user.email === email && user.password === password);

    if (user) {
        alert("Login successful!");
        // Optionally, redirect or display another message here
        window.location.href = "homepage.html"; // Redirect to another page (change URL as needed)
    } else {
        alert("Invalid email or password!");
    }
});

// Event listener for the sign-up form submission (optional, as it’s not really functional in this case)
signUpForm.addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission
    alert("Sign Up functionality is not implemented.");
});

// Toggle between Sign Up and Sign In forms
const signInButton = document.getElementById("signIn");
const signUpButton = document.getElementById("signUp");

signInButton.addEventListener("click", function() {
    document.querySelector(".sign-up-container").style.transform = "translateX(100%)";
    document.querySelector(".sign-in-container").style.transform = "translateX(0)";
});

signUpButton.addEventListener("click", function() {
    document.querySelector(".sign-in-container").style.transform = "translateX(100%)";
    document.querySelector(".sign-up-container").style.transform = "translateX(0)";
});
